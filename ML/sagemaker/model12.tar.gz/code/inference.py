import argparse
import os
import json
import torch
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class MANM(nn.Module):
    def __init__(self, word_to_vec, max_sent_size, memory_num, embedding_size, feature_size,
                  score_range, hops, l2_lambda, keep_prob, device):
        super(MANM, self).__init__()
        self.max_sent_size = max_sent_size
        self.memory_num = memory_num
        self.hops = hops
        self.l2_lambda = l2_lambda
        self.keep_prob = keep_prob
        self.score_range = score_range
        self.feature_size = feature_size
        self.embedding_size = embedding_size
        self.device = device
        self.word_to_vec = torch.nn.Embedding.from_pretrained(torch.from_numpy(word_to_vec), freeze=True)
        # [embedding_size, max_sent_size]
        self.pos_encoding = self.position_encoding(self.max_sent_size, self.embedding_size).requires_grad_(False).to(self.device)

        # shape [k, d]
        self.A = torch.nn.Embedding(self.feature_size, self.embedding_size).to(self.device)
        self.B = torch.nn.Embedding(self.feature_size, self.embedding_size).to(self.device)
        self.C = torch.nn.Embedding(self.feature_size, self.embedding_size).to(self.device)
        torch.nn.init.xavier_uniform_(self.A.weight)
        torch.nn.init.xavier_uniform_(self.B.weight)
        torch.nn.init.xavier_uniform_(self.C.weight)
        # shape [k, k]
        Rlist = []
        for i in range(self.hops):
            R = torch.nn.Embedding(self.feature_size, self.feature_size).to(self.device)
            torch.nn.init.xavier_uniform_(R.weight)
            Rlist.append(R)
        self.R_list = torch.nn.ModuleList(Rlist)
        # shape [k, r]
        self.W = torch.nn.Embedding(self.feature_size, self.score_range).to(self.device)
        torch.nn.init.xavier_uniform_(self.W.weight)
        # bias in last layer
        self.b = torch.nn.Parameter(torch.randn([self.score_range]))

    def forward(self, contents_idx:np.ndarray, memories_idx:np.ndarray, scores:np.ndarray):
        contents_idx = torch.from_numpy(contents_idx).to(self.device).requires_grad_(False)
        memories_idx = torch.from_numpy(memories_idx).to(self.device).requires_grad_(False)
        # [batch_size, max_sent_size, embedding_size]
        contents = self.word_to_vec(contents_idx)
        # [batch_size, memory_num, max_sent_size, embedding_size]
        memories = self.word_to_vec(memories_idx)
        # emb_contents [batch_size, d]    d=embedding_size
        # emb_memories [batch_size, memory_num, d]
        emb_contents, emb_memories = self.input_representation_layer(contents, memories)
        dropout = torch.nn.Dropout(p=1 - self.keep_prob)
        emb_contents = dropout(emb_contents).requires_grad_(False)
        # [batch_size, k] = [batch_size, d] x [d, k]
        u = torch.matmul(emb_contents, self.A.weight.transpose(0, 1))

        for i in range(self.hops):
            prob_vectors, used_emb_memories = self.memory_addressing_layer(u, emb_memories)  # [batch_size, memory_num]
            u = self.memory_reading_layer(i, u, prob_vectors, used_emb_memories)  # [batch_size, k]

        # [batch_size, memory_num]   distribution is softmax(logits)
        logits, distribution = self.output_layer(u)
        losser = torch.nn.CrossEntropyLoss()
        scores = torch.from_numpy(scores).requires_grad_(False).to(self.device)
        loss1 = torch.sum(losser(logits, scores))  # score: [batch_size]
        loss2 = (torch.sum(self.A.weight**2) + torch.sum(self.B.weight**2) +
                  torch.sum(self.C.weight**2) + torch.sum(self.W.weight**2) + torch.sum(self.b**2))/2
        for m in range(self.hops):
            loss2 += torch.sum(self.R_list[m].weight**2)/2
        loss = loss1+loss2*self.l2_lambda
        return loss

    def position_encoding(self, sentence_size, embedding_size):
        encoding = np.ones((embedding_size, sentence_size), dtype=np.float32)
        ls = sentence_size + 1
        le = embedding_size + 1
        for i in range(1, le):
            for j in range(1, ls):
                encoding[i - 1, j - 1] = (i - (le - 1) / 2) * (j - (ls - 1) / 2)
        encoding = 1 + 4 * encoding / embedding_size / sentence_size
        pos_encoding = torch.from_numpy(encoding)
        return pos_encoding.transpose(0, 1)

    def input_representation_layer(self, contents: torch.Tensor, memories: torch.Tensor):
        '''bow'''
        # contents [batch_size, max_sent_size, embedding_size]
        # memories [batch_size, memory_num, max_sent_size, embedding_size]
        # self.pos_encoding: [max_sent_size, embedding_size]
        emb_contents = torch.sum(contents*self.pos_encoding, dim=1).requires_grad_(False)  # *表示对位相乘
        # print(memories.shape,  self.pos_encoding.shape)
        emb_memories = torch.sum(memories*self.pos_encoding, dim=2).requires_grad_(False)  # *表示对位相乘
        return emb_contents, emb_memories

    def memory_addressing_layer(self, u, emb_memories):
        dropout = torch.nn.Dropout(p=1-self.keep_prob)
        used_emb_memories = dropout(emb_memories).requires_grad_(False)
        # [batch_size, memory_num, k] = [batch_size, memory_num, d] x [d, k]
        trans_emb_memories = torch.matmul(used_emb_memories, self.B.weight.transpose(0,1))
        # dot product
        # [batch_size, memory_num, k] <- [batch_size, k]
        trans_emb_contents = u.unsqueeze(dim=1)
        # product [batch_size, memory_num]  *表示对位相乘
        product = torch.sum(trans_emb_contents*trans_emb_memories, dim=-1)  # 对最后一维进行sum
        # prob_vectors [batch_size, memory_num]
        prob_vectors = F.softmax(product, dim=-1)
        return prob_vectors, used_emb_memories

    def memory_reading_layer(self, i, u, prob_vectors, used_emb_memories):
        # [batch_size, memory_num, 1]
        prob_vectors = torch.unsqueeze(prob_vectors, dim=2)
        # [batch_size * memory_num, d]
        memo_temp = used_emb_memories.view(-1, self.embedding_size)
        # print("used_emb_memories size: ", memo_temp.shape)
        # [d, batch_size * memory_num]
        memo_temp = memo_temp.transpose(0, 1)
        # [k, batch_size * memory_num]
        product = torch.matmul(self.C.weight, memo_temp)
        # print(product.shape)
        # [batch_size, memory_num, k]
        product = torch.reshape(product.transpose(0, 1), [-1, self.memory_num, self.feature_size])
        # product = torch.matmul(used_emb_memories, self.C.weight.transpose(0,1))
        # [batch_size, k]
        o = torch.sum(prob_vectors*product, dim=1)
        # [batch_size, k]
        u = F.relu(torch.matmul((o+u), self.R_list[i].weight))
        return u

    def output_layer(self, u):
        # [batch_size, score_range]
        logits = torch.matmul(u, self.W.weight)+self.b
        distribution = F.softmax(logits, dim=1)
        return logits, distribution

    def test(self, contents_idx, memories_idx):
        contents_idx = torch.from_numpy(contents_idx).to(self.device).requires_grad_(False)
        memories_idx = torch.from_numpy(memories_idx).to(self.device).requires_grad_(False)
        # [batch_size, max_sent_size, embedding_size]
        contents = self.word_to_vec(contents_idx)
        # [batch_size, memory_num, max_sent_size, embedding_size]
        memories = self.word_to_vec(memories_idx)
        # emb_contents [batch_size, d]    d=embedding_size
        # emb_memories [batch_size, memory_num, d]
        emb_contents, emb_memories = self.input_representation_layer(contents, memories)
        self.keep_prob = 1
        # [batch_size, k] = [batch_size, d] x [d, k]
        u = torch.matmul(emb_contents, self.A.weight.transpose(0, 1))

        for i in range(self.hops):
            prob_vectors, used_emb_memories = self.memory_addressing_layer(u, emb_memories)  # [batch_size, memory_num]
            u = self.memory_reading_layer(i, u, prob_vectors, used_emb_memories)  # [batch_size, k]

        # [batch_size, memory_num]
        logits, distribution = self.output_layer(u)
        # print(distribution)
        # [batch_size]
        pred_scores = torch.argmax(distribution, dim=1)
        return pred_scores

if __name__ =='__main__':

    parser = argparse.ArgumentParser()
    # input data and model directories
    parser.add_argument('--model-dir', type=str, default=os.environ['SM_MODEL_DIR'])
    print(os.environ['SM_MODEL_DIR'])
    args, _ = parser.parse_known_args()

def input_fn(request_body, content_type):
    print(request_body, "input0")
    b =  request_body.decode('utf-8')
    print(b, "input1")
    return b

def model_fn(model_dir):
    """
    Load the model for inference
    """
    import logging
    import math
    import numpy as np
    from scipy.stats import kendalltau, spearmanr, pearsonr
    from six import string_types
    from six.moves import xrange as range
    from sklearn.metrics import confusion_matrix, f1_score, SCORERS
    # from sklearn.metrics import mean_squared_error


    # Constants
    _CORRELATION_METRICS = frozenset(['kendall_tau', 'spearman', 'pearson'])


    def kappa(y_true, y_pred, weights=None, allow_off_by_one=False):
        """
        Calculates the kappa inter-rater agreement between two the gold standard
        and the predicted ratings. Potential values range from -1 (representing
        complete disagreement) to 1 (representing complete agreement).  A kappa
        value of 0 is expected if all agreement is due to chance.
        In the course of calculating kappa, all items in `y_true` and `y_pred` will
        first be converted to floats and then rounded to integers.
        It is assumed that y_true and y_pred contain the complete range of possible
        ratings.
        This function contains a combination of code from yorchopolis's kappa-stats
        and Ben Hamner's Metrics projects on Github.
        :param y_true: The true/actual/gold labels for the data.
        :type y_true: array-like of float
        :param y_pred: The predicted/observed labels for the data.
        :type y_pred: array-like of float
        :param weights: Specifies the weight matrix for the calculation.
                        Options are:
                            -  None = unweighted-kappa
                            -  'quadratic' = quadratic-weighted kappa
                            -  'linear' = linear-weighted kappa
                            -  two-dimensional numpy array = a custom matrix of
                               weights. Each weight corresponds to the
                               :math:`w_{ij}` values in the wikipedia description
                               of how to calculate weighted Cohen's kappa.
        :type weights: str or numpy array
        :param allow_off_by_one: If true, ratings that are off by one are counted as
                                 equal, and all other differences are reduced by
                                 one. For example, 1 and 2 will be considered to be
                                 equal, whereas 1 and 3 will have a difference of 1
                                 for when building the weights matrix.
        :type allow_off_by_one: bool
        """
        logger = logging.getLogger(__name__)

        # Ensure that the lists are both the same length
        assert(len(y_true) == len(y_pred))
        # This rather crazy looking typecast is intended to work as follows:
        # If an input is an int, the operations will have no effect.
        # If it is a float, it will be rounded and then converted to an int
        # because the ml_metrics package requires ints.
        # If it is a str like "1", then it will be converted to a (rounded) int.
        # If it is a str that can't be typecast, then the user is
        # given a hopefully useful error message.
        # Note: numpy and python 3.3 use bankers' rounding.
        try:
            y_true = [int(np.round(float(y))) for y in y_true]
            y_pred = [int(np.round(float(y))) for y in y_pred]
        except ValueError as e:
            logger.error("For kappa, the labels should be integers or strings "
                         "that can be converted to ints (E.g., '4.0' or '3').")
            raise e

        # Figure out normalized expected values
        min_rating = min(min(y_true), min(y_pred))
        max_rating = max(max(y_true), max(y_pred))

        # shift the values so that the lowest value is 0
        # (to support scales that include negative values)
        y_true = [y - min_rating for y in y_true]
        y_pred = [y - min_rating for y in y_pred]

        # Build the observed/confusion matrix
        num_ratings = max_rating - min_rating + 1
        observed = confusion_matrix(y_true, y_pred,
                                    labels=list(range(num_ratings)))
        num_scored_items = float(len(y_true))

        # Build weight array if weren't passed one
        if isinstance(weights, string_types):
            wt_scheme = weights
            weights = None
        else:
            wt_scheme = ''
        if weights is None:
            weights = np.empty((num_ratings, num_ratings))
            for i in range(num_ratings):
                for j in range(num_ratings):
                    diff = abs(i - j)
                    if allow_off_by_one and diff:
                        diff -= 1
                    if wt_scheme == 'linear':
                        weights[i, j] = diff
                    elif wt_scheme == 'quadratic':
                        weights[i, j] = diff ** 2
                    elif not wt_scheme:  # unweighted
                        weights[i, j] = bool(diff)
                    else:
                        raise ValueError('Invalid weight scheme specified for '
                                         'kappa: {}'.format(wt_scheme))

        hist_true = np.bincount(y_true, minlength=num_ratings)
        hist_true = hist_true[: num_ratings] / num_scored_items
        hist_pred = np.bincount(y_pred, minlength=num_ratings)
        hist_pred = hist_pred[: num_ratings] / num_scored_items
        expected = np.outer(hist_true, hist_pred)

        # Normalize observed array
        observed = observed / num_scored_items

        # If all weights are zero, that means no disagreements matter.
        k = 1.0
        if np.count_nonzero(weights):
            k -= (sum(sum(weights * observed)) / sum(sum(weights * expected)))

        return k



    def kendall_tau(y_true, y_pred):
        """
        Calculate Kendall's tau between ``y_true`` and ``y_pred``.
        :param y_true: The true/actual/gold labels for the data.
        :type y_true: array-like of float
        :param y_pred: The predicted/observed labels for the data.
        :type y_pred: array-like of float
        :returns: Kendall's tau if well-defined, else 0
        """
        ret_score = kendalltau(y_true, y_pred)[0]
        return ret_score if not np.isnan(ret_score) else 0.0



    def spearman(y_true, y_pred):
        """
        Calculate Spearman's rank correlation coefficient between ``y_true`` and
        ``y_pred``.
        :param y_true: The true/actual/gold labels for the data.
        :type y_true: array-like of float
        :param y_pred: The predicted/observed labels for the data.
        :type y_pred: array-like of float
        :returns: Spearman's rank correlation coefficient if well-defined, else 0
        """
        ret_score = spearmanr(y_true, y_pred)[0]
        return ret_score if not np.isnan(ret_score) else 0.0



    def pearson(y_true, y_pred):
        """
        Calculate Pearson product-moment correlation coefficient between ``y_true``
        and ``y_pred``.
        :param y_true: The true/actual/gold labels for the data.
        :type y_true: array-like of float
        :param y_pred: The predicted/observed labels for the data.
        :type y_pred: array-like of float
        :returns: Pearson product-moment correlation coefficient if well-defined,
                  else 0
        """
        ret_score = pearsonr(y_true, y_pred)[0]
        return ret_score if not np.isnan(ret_score) else 0.0



    def f1_score_least_frequent(y_true, y_pred):
        """
        Calculate the F1 score of the least frequent label/class in ``y_true`` for
        ``y_pred``.
        :param y_true: The true/actual/gold labels for the data.
        :type y_true: array-like of float
        :param y_pred: The predicted/observed labels for the data.
        :type y_pred: array-like of float
        :returns: F1 score of the least frequent label
        """
        least_frequent = np.bincount(y_true).argmin()
        return f1_score(y_true, y_pred, average=None)[least_frequent]



    def use_score_func(func_name, y_true, y_pred):
        """
        Call the scoring function in `sklearn.metrics.SCORERS` with the given name.
        This takes care of handling keyword arguments that were pre-specified when
        creating the scorer. This applies any sign-flipping that was specified by
        `make_scorer` when the scorer was created.
        """
        scorer = SCORERS[func_name]
        return scorer._sign * scorer._score_func(y_true, y_pred, **scorer._kwargs)


    def mean_square_error(y_true, y_pred):
        """
        Calculate the mean square error between predictions and true scores
        :param y_true: true score list
        :param y_pred: predicted score list
        return mean_square_error value
        """
        # return mean_squared_error(y_true, y_pred) # use sklean default function
        y_true = np.asarray(y_true)
        y_pred = np.asarray(y_pred)
        mse = ((y_true-y_pred)**2).mean(axis=0)
        return float(mse)


    def root_mean_square_error(y_true, y_pred):
        """
        Calculate the mean square error between predictions and true scores
        :param y_true: true score list
        :param y_pred: predicted score list
        return mean_square_error value
        """
        # return mean_squared_error(y_true, y_pred) # use sklean default function
        y_true = np.asarray(y_true)
        y_pred = np.asarray(y_pred)
        mse = ((y_true-y_pred)**2).mean(axis=0)
        return float(math.sqrt(mse))

    with open(os.path.join(model_dir, 'model.pth'), 'rb') as f:
        if torch.cuda.is_available():
            checkpoint = torch.load(f)
        else:
            checkpoint = torch.load(f, map_location=torch.device('cpu'))
    config_saved = checkpoint['config']
    CONFIGS = {"gpu_id" : 0,
    "set_id" : 1 ,#essay set id, 1 <: id <: 8
    "emb_size" : config_saved['embedding'] ,#Embedding size for sentences
    "token_num" : 42 ,#The number of token in glove (6, 42
    "feature_size" : config_saved['feature_size'] ,#Feature size
    "epochs" : 200 ,#Number of epochs to train for
    "test_freq" : 20 ,#Evaluate and print results every x epochs
    "hops" : config_saved['hops'] ,#Number of hops in the Memory Network
    "lr" : 0.0005,#Learning rate
    "batch_size" : 16 ,#Batch size for training
    "l2_lambda" : config_saved['l2_lambda'],#Lambda for l2 loss
    "num_samples" : 1 ,#Number of samples selected as memories for
    "epsilon" : 0.1 ,#Epsilon value for Adam Optimizer
    "max_grad_norm" : 10.0 ,#Clip gradients to this norm
    "keep_prob" : config_saved['keep_prob'] ,#Keep probability for dropout
    }
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print("here0")
    memory_num = checkpoint['memory'].shape[0]
    max_sent_size= checkpoint['memory'].shape[1]
    word_to_vec = np.zeros((len(checkpoint['word_to_index'])+1,300))
    print("here1")
    model = MANM(word_to_vec=word_to_vec, max_sent_size=max_sent_size, memory_num=memory_num, embedding_size=CONFIGS['emb_size'],
                  feature_size=CONFIGS['feature_size'], score_range=121, hops=CONFIGS['hops'],
                  l2_lambda=CONFIGS['l2_lambda'], keep_prob=CONFIGS['keep_prob'], device=device).to(device)
    print("here1")
    print(model_dir)
    print("aaaaa")
    
    model.load_state_dict(checkpoint['model_state_dict'])
    print("here2")
    model.device=device
    model.eval()
    return model



def predict_fn(input_data, model):    
    from utils import tokenize, vectorize_data
    from utils import clean_str
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    model.eval()
    model = model.double()
    with torch.no_grad():
        print(input_data)
        contents = [input_data]
        essay_contents = []
        for index, content in enumerate(contents):
            content = clean_str(content)
            essay_contents.append(tokenize(content))
        cwd = os.getcwd()

        with open('../../model/model.pth', 'rb') as f:
            if torch.cuda.is_available():
                checkpoint = torch.load(f)
            else:
                checkpoint = torch.load(f, map_location=torch.device('cpu'))
            memory_contents = checkpoint['memory']
            word_to_index = checkpoint['word_to_index']

        max_sent = memory_contents.shape[1]
        test_contents_idx = vectorize_data(essay_contents, word_to_index, memory_contents.shape[1])
        test_contents = np.array(test_contents_idx, dtype=np.int64)
        batched_memory_contents = np.array([memory_contents]*test_contents.shape[0], dtype=np.int64)
        print("predict0")
        pred_scores = model.test(test_contents, batched_memory_contents).cpu().numpy()
        pred_scores = np.add(pred_scores, 5)
        return torch.Tensor(pred_scores)
