import json
import boto3
import uuid
from prompt_mapper import *
#import jwt

# from time import gmtime, strftime
db = boto3.resource('dynamodb')
table = db.Table('essays')


runtime= boto3.client('runtime.sagemaker')
from decimal import Decimal
def lambda_handler(event, context):
    # print(event)
    userid = event['userid']
    
    # TODO: change to the following for cognito
    # token = event['Authorization']
    # decoded = jwt.decode(token, options={"verify_signature": False}) # works in PyJWT >= v2.0
    # user_email = decoded['email']
    
    essay = event['essay']
    prompt = event['prompt']
    print(prompt)
    promptid = get_id(prompt)
    # ENDPOINT_NAME = 'model9-essay-scoring-endpoint' 
    # if int(promptid) in [1,9]:
    ENDPOINT_NAME = 'model' + promptid+ '-essay-scoring-endpoint'
    #to do change it 
  
    encoded_string = essay.encode("utf-8")
    essayID = str(uuid.uuid4())
    bucket_name = "essay-storage"
    file_name = essayID+".txt"
    # s3_path = 
    s3 = boto3.resource("s3")
    s3.Bucket(bucket_name).put_object(Key=file_name, Body=encoded_string)

    
    
    #todo sagemaker
    
    # payload = essay.encode('utf-8')
    # response = runtime.invoke_endpoint(
    #     EndpointName=ENDPOINT_NAME, 
    #     Body=payload
    #     )
    
    # # print(response['Body'])  
    # result = json.loads(response['Body'].read().decode())
    # print(result[0])
    # score =float(result[0])/10.0
    score = 5.0
    print(score)
    essay_link = "https:/essay-storage.s3.amazonaws.com/" + file_name
    
    
    ## get beat rate
    beat_rate = 0
    response = table.scan()
    data = response['Items']
    total_count = 0
    less_count = 0

    for ele in data:
        
        if ele['promptid'] == promptid:
            total_count += 1
            if ele['score'] <= score:
                less_count += 1
    if total_count == 0:
        beat_rate = 1
    else:
        beat_rate = round(less_count/total_count, 2)
        
    response = table.put_item (Item = {
        "userID":userid,
        "essayID": essayID,
        "essay_link": essay_link,
        "prompt" : prompt,
        "promptid": promptid,
        "score" : Decimal(str(score))
    })
    
    return {
        'statusCode': 200,
        'body': json.dumps('You have succesfully submitted the response! See your result in next page. '),
        'score': score,
        'rate': beat_rate*100
    }
