import boto3
import json

'''
s3 = boto3.resource('s3')
id_to_prompt = s3.Object('code-bucket-final-project', 'id_to_prompt.json')
prompt_to_id = s3.Object('code-bucket-final-project', 'prompt_to_id.json')

id_to_prompt_f = id_to_prompt.get()['Body'].read().decode('utf-8')
prompt_to_id_f = prompt_to_id.get()['Body'].read().decode('utf-8')


id_to_prompt_dict = json.loads(id_to_prompt_f)
prompt_to_id_dict = json.loads(prompt_to_id_f)
'''




prompt_to_id_dict = {
  "<p>Do you agree or disagree with the following statement? Coaches are the best teachers. Use specific reasons and examples to support your answer.</p>":"1",
  "<p>Do you agree or disagree with the following statement? Universities should give the same amount of money to their students\' sports activities as they give to their university libraries. Use specific reasons and examples to support your opinion.</p>":"2",
  "<p>Do you agree or disagree with the following statement? Television, newspapers, magazines, and other media pay too much attention to the personal lives of famous people such as public figures and celebrities. Use specific reasons and details to explain your opinion.</p>": "3",
  "<p>People attend school for many different reasons (for example, expanded knowledge, societal awareness, and enhanced interpersonal relationships). Why do you think people decide to go to school? Use specific reasons and examples to support your answer.</p>": "4",
  "<p>Write about one of your favorite family traditions.Use specific reasons and examples to support your answer.</p>": "5",
  "<p>There are many skills that will help people be successful today. What is a very important skill a person should learn in order to be successful in the world today? Choose one skill and use specific reasons and examples to support your choice.</p>": "6",
  "<p>There are many types of entertainment today. Movies and television are very popular. How do movies or television influence people’s behavior? Use reasons and specific examples to support your answer.</p>": "7",
  "<p>Do you agree or disagree with the following statement? Important decisions should never be made alone. Use specific reasons and examples to support your answer.</p>": "8",
  "<p>Do you agree or disagree with the following statement? Being self confident is the most important character trait that you can have.Use specific reasons for your answer.</p>": "9",
  "<p>Some say that physical exercise should be a required part of every school day. Others believe that students should spend the whole school day on academic studies. Which opinion do you agree with? Use specific reasons and details to support your answer.</p>": "10",
  "<p>What do you consider to be the most important subject in school? Why is this subject more important to you than any other subject? Use specific reasons and examples to support your opinion.</p>": "11",
  "<p>Some people prefer to plan activities for their free time very carefully. Others choose not to make any plans at all for their free time. Think about the benefits of planning free-time activities vs the benefits of not making plans. Which do you prefer planning or not planning your leisure time? Use specific reasons and examples to explain your choice.</p>": "12",
  "<p>Write about your favorite vacation spot.Describe it and write about why you like it so much.</p>": "13",
  "<p>Write about the role of technology in today's world. Compare and contrast the advantages and the disadvantages.</p>": "14"
}

id_to_prompt_dict = {}
for prompt in prompt_to_id_dict:
    id_to_prompt_dict[prompt_to_id_dict[prompt]] = prompt
    
def get_id(prompt):
    if prompt not in prompt_to_id_dict:
        return "1"
    return prompt_to_id_dict.get(prompt)

def get_prompt(id):
    print(id_to_prompt_dict.items())
    return id_to_prompt_dict.get(id)

