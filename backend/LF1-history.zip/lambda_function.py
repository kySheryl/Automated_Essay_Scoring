import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
import logging
from prompt_mapper import *
#import jwt

logger = logging.getLogger()
logger.setLevel(logging.INFO)
s3 = boto3.resource('s3')
bucket = s3.Bucket('essay-storage')
def lambda_handler(event, context):

    print('event is', event)
    userid = event['userid']
    
    # TODO: change to the following for cognito
    # token = event['Authorization']
    # decoded = jwt.decode(token, options={"verify_signature": False}) # works in PyJWT >= v2.0
    # user_email = decoded['email']
    
    prompt = event['prompt']
    promptid = get_id(prompt)
    
    #####TODO: given userid and promptid, search for history
    client = boto3.resource('dynamodb')
    table = client.Table('essays')
    response = table.query(KeyConditionExpression=Key('userID').eq(userid),FilterExpression=Attr('promptid').eq(promptid))
    print('response is', response)
    data = response['Items']
    logger.info('data from dynamodb is ' + str(data))
    result = []
    for ele in data: 
        itemname = ele["essay_link"].split('/')[-1]
        obj = s3.Object('essay-storage', itemname)
        body = obj.get()['Body'].read()
        result.append({'essay' : body, "score":ele['score']})
        
    # result = [
    #     {
    #         "essay": "essaycontent1",
    #         "score": 2.5
    #     },
    #     {
    #         "essay": "essaycontent2",
    #         "score": 9.0
    #     }
    #     ]
    result.sort(key = lambda x: x["score"], reverse = True)
    return {
        'statusCode': 200,
        'body': result
    }
